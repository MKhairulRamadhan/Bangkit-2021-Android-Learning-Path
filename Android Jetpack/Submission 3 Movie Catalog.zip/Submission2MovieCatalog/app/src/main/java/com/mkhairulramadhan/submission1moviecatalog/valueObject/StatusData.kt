package com.mkhairulramadhan.submission1moviecatalog.valueObject

enum class StatusData {
    SUCCESS,
    ERROR,
    LOADING
}