package com.mkhairulramadhan.submission1moviecatalog.data.remote

data class Genre(
    val id: Int? = null,
    val name: String? = null
)