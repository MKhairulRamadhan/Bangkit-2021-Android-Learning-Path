package com.mkhairulramadhan.submission1moviecatalog.data.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}