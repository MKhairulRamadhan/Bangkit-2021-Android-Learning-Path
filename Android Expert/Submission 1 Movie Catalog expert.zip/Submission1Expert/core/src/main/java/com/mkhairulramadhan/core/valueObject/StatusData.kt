package com.mkhairulramadhan.core.valueObject

enum class StatusData {
    SUCCESS,
    ERROR,
    LOADING
}