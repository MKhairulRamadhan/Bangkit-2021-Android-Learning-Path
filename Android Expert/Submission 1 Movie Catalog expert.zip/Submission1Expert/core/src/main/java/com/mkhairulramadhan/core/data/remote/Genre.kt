package com.mkhairulramadhan.core.data.remote

data class Genre(
    val id: Int? = null,
    val name: String? = null
)